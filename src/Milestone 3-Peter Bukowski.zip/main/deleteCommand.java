package main;

import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

public class deleteCommand implements ICommand {
    private IApplicationState appState;

    public deleteCommand(IApplicationState appState) {
        this.appState = appState;
    }

    @Override
    public void run() {
        for (Shape s : appState.getShapelist()) {
            if (s.isSelected == true) {
               // get rid of it from the shape list
                s.clearShape();
            }
        }
    }
}
