package main;
import model.ShapeColor;
import model.ShapeShadingType;
import model.ShapeType;
import model.StartAndEndPointMode;
import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;
import java.awt.*;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class ShapeCommand implements ICommand {
    private Point startPoint;
    private Point endPoint;
    private PaintCanvasBase paintCanvas;
    private IApplicationState appState;

    public ShapeCommand(Point startPoint, Point endPoint, PaintCanvasBase paintCanvas,IApplicationState appState) {
        this.startPoint=startPoint;
        this.endPoint=endPoint;
        this.paintCanvas=paintCanvas;
        this.appState=appState;
    }

    @Override
    public void run() {
        if(appState.getActiveStartAndEndPointMode().equals(StartAndEndPointMode.DRAW)) {
            getShapeFactory get = new getShapeFactory();
            get.getShape(appState, startPoint, endPoint, paintCanvas);
        }
       if(appState.getActiveStartAndEndPointMode().equals(StartAndEndPointMode.SELECT)){
           ICommand coman= new selectCommand(startPoint,endPoint,paintCanvas,appState);
           coman.run();

       }
        if(appState.getActiveStartAndEndPointMode().equals(StartAndEndPointMode.MOVE)){
            ICommand coman= new moveCommand(startPoint,endPoint,paintCanvas,appState);
            coman.run();

        }



    }

}
