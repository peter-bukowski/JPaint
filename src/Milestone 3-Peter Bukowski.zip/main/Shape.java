package main;

import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import java.awt.*;

public abstract class Shape {
     Point startPoint;
     Point endPoint;
     PaintCanvasBase paintCanvas;
     IApplicationState appState;
     Boolean isPoly;
     Boolean isSelected;
     Graphics2D graphics2d;

     public  abstract void drawShape();

     public abstract Boolean isPolygon();

     public abstract void setSelected(Boolean answ);

     public abstract Boolean IsSelected();


     public abstract void clearShape();

     public abstract void setX(int point);
     public abstract  void setY(int point);
     public abstract void setX1(int point);

     public abstract void setY1(int point) ;
     public abstract void setNewX();
     public abstract void setNewY();

     public  abstract int getX();

     public  abstract int getY();
     public abstract int getX1();
     public abstract int getY1();

     public abstract void selectShape();


     public abstract int getNewWidth();

     public abstract int getNewHeight();
}
