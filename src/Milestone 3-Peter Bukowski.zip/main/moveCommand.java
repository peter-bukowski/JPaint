package main;

import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import java.awt.*;

public class moveCommand implements ICommand{

    private Point startPoint;
    private Point endPoint;
    private PaintCanvasBase paintCanvas;
    private IApplicationState appState;
    private Point deltaTlBR;//Top left Bottom Right
    private Point deltaBRTL; //Bottom Right Top Left
    private Point deltaBLTR;
    private Point deltaBLTRS;



    public moveCommand(Point startPoint, Point endPoint, PaintCanvasBase paintCanvas, IApplicationState appState) {
        this.startPoint=startPoint;
        this.endPoint=endPoint;
        this.paintCanvas=paintCanvas;
        this.appState=appState;
    }





    @Override
    public void run() {
        /// pop shapes out of list
        int newX;
        int newY;
        int newX1;
        int newY1;
        Boolean result;
        deltaTlBR=new Point(endPoint.getX()-startPoint.getX(),endPoint.getY()-startPoint.getY());
        deltaBRTL= new Point(startPoint.getX()-endPoint.getX(),startPoint.getY()-endPoint.getY());
        deltaBLTR= new Point(endPoint.getX()-startPoint.getX(),startPoint.getY()-endPoint.getY());
        deltaBLTRS= new Point(startPoint.getX()-endPoint.getX(),endPoint.getY()-startPoint.getY());
        Graphics2D graphics2d = paintCanvas.getGraphics2D();
        graphics2d.setColor(Color.white);
        graphics2d.fillRect(0 ,0, paintCanvas.getWidth(), paintCanvas.getHeight());


        for(Shape s:appState.getShapelist()){
            result=s.isPolygon();
            if(startPoint.getX()<endPoint.getX()&&startPoint.getY()<endPoint.getY() && s.isSelected==true){
                if(result){
                    newX=s.getX()+deltaTlBR.getX();
                    newY=s.getY()+deltaTlBR.getY();
                    newX1=s.getX1()+deltaTlBR.getX();
                    newY1=s.getY1()+deltaTlBR.getY();
                    s.setX(newX);
                    s.setY(newY);
                    s.setX1(newX1);
                    s.setY1(newY1);
                    s.setNewX();
                    s.setNewY();
                    s.drawShape();
                }
                newX=s.getX()+deltaTlBR.getX();
                newY=s.getY()+deltaTlBR.getY();
                s.setX(newX);
                s.setY(newY);
                s.drawShape();

            }
            if(startPoint.getX()>endPoint.getX()&&startPoint.getY()>endPoint.getY()&& s.isSelected==true){
                if(result){
                    newX=s.getX()-deltaBRTL.getX();
                    newY=s.getY()-deltaBRTL.getY();
                    newX1=s.getX1()-deltaBRTL.getX();
                    newY1=s.getY1()-deltaBRTL.getY();
                    s.setX(newX);
                    s.setY(newY);
                    s.setX1(newX1);
                    s.setY1(newY1);
                    s.setNewX();
                    s.setNewY();
                    s.drawShape();
                }
                newX=s.getX()-deltaBRTL.getX();
                newY=s.getY()-deltaBRTL.getY();
                s.setX(newX);
                s.setY(newY);
                s.drawShape();

            }
            if(endPoint.getX()>startPoint.getX()&&startPoint.getY()>endPoint.getY()&& s.isSelected==true){
                if(result){
                    newX=s.getX()+deltaBLTR.getX();
                    newY=s.getY()-deltaBLTR.getY();
                    newX1=s.getX1()+deltaBLTR.getX();
                    newY1=s.getY1()-deltaBLTR.getY();
                    s.setX(newX);
                    s.setY(newY);
                    s.setX1(newX1);
                    s.setY1(newY1);
                    s.setNewX();
                    s.setNewY();
                    s.drawShape();

                }
                newX=s.getX()+deltaBLTR.getX();
                newY=s.getY()-deltaBLTR.getY();
                s.setX(newX);
                s.setY(newY);
                s.drawShape();
            }
            if(startPoint.getX()>endPoint.getX()&&endPoint.getY()>startPoint.getY()&& s.isSelected==true){
                if(result){
                    newX=s.getX()-deltaBLTRS.getX();
                    newY=s.getY()+deltaBLTRS.getY();
                    newX1=s.getX1()-deltaBLTRS.getX();
                    newY1=s.getY1()+deltaBLTRS.getY();
                    s.setX(newX);
                    s.setY(newY);
                    s.setX1(newX1);
                    s.setY1(newY1);
                    s.setNewX();
                    s.setNewY();
                    s.drawShape();
                }
                newX=s.getX()-deltaBLTRS.getX();
                newY=s.getY()+deltaBLTRS.getY();
                s.setX(newX);
                s.setY(newY);
                s.drawShape();


            }
            if(s.isSelected==false){
                s.drawShape();
            }


            }








    }


}
