package main;

public interface drawStrategy {


    public void drawOutline();

    public void drawFilled();

    public void drawOutlineFilled();






}
