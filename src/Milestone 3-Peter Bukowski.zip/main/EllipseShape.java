package main;

import model.ShapeColor;
import model.ShapeShadingType;
import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import java.awt.*;

 class EllipseShape extends Shape  {
     int newWidth;
     int newHeight;
     Point selectPoint;
     int y;
     int x;
     drawStrategy drawEllipse;


    public EllipseShape(Point startPoint, Point endPoint, PaintCanvasBase paintCanvas,IApplicationState appState) {
        this.startPoint=startPoint;
        this.endPoint=endPoint;
        this.paintCanvas=paintCanvas;
        this.appState=appState;
        newWidth= Math.abs(endPoint.getX() - startPoint.getX());
        newHeight=Math.abs(endPoint.getY() - startPoint.getY());
        selectPoint=new Point(Math.min(startPoint.getX(),endPoint.getX()),Math.min(startPoint.getY(),endPoint.getY()));
        x=selectPoint.getX();
        y=selectPoint.getY();
        //drawShape();

    }

    public void drawShape(){
        drawEllipse=new drawEllipse(paintCanvas,appState,getX(),getY(),getNewWidth(),getNewHeight());


}


     @Override
     public Boolean isPolygon() {
        isPoly=false;
         return isPoly;
     }

     @Override
     public void setSelected(Boolean answ) {
        isSelected=answ;

     }

     @Override
     public Boolean IsSelected() {
         return isSelected;
     }

     @Override
     public void clearShape() {
         Graphics2D graphics2d = paintCanvas.getGraphics2D();
         graphics2d.setColor(Color.WHITE);
         graphics2d.fillRect(getX()-10, getY()-10,getNewWidth()+20,getNewHeight()+20);
     }

     @Override
     public void setX(int point) {
        x=point;

     }

     @Override
     public void setY(int point) {
          y=point;
     }

     @Override
     public void setX1(int point) {

     }

     @Override
     public void setY1(int point) {

     }

     @Override
     public void setNewX() {

     }

     @Override
     public void setNewY() {

     }

     @Override
     public int getX() {
         return x;
     }

     @Override
     public int getY() {
         return y;
     }

     @Override
     public int getX1() {
         return 0;
     }

     @Override
     public int getY1() {
         return 0;
     }

     public void selectShape(){
         Graphics2D graphics2d = paintCanvas.getGraphics2D();
         Stroke stroke = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, new float[]{9}, 0);
         graphics2d.setStroke(stroke);
         graphics2d.setColor(Color.BLACK);
         graphics2d.drawOval(selectPoint.getX()-5,selectPoint.getY()-5,newWidth+10,newHeight+10);
     }

     public int getNewWidth(){
         return newWidth;
     }
     public int getNewHeight(){
         return newHeight;
     }




}

   /*  Graphics2D graphics2d = paintCanvas.getGraphics2D();
        graphics2d.setColor(ShapeColor.getColor(appState.getActivePrimaryColor()));
                if(appState.getActiveShapeShadingType().equals(ShapeShadingType.OUTLINE)){
                graphics2d.drawOval(getX(), getY(), getNewWidth(), getNewHeight());
                }
                if(appState.getActiveShapeShadingType().equals(ShapeShadingType.FILLED_IN)){
                graphics2d.fillOval(getX(), getY(), getNewWidth(), getNewHeight());
                }
                if(appState.getActiveShapeShadingType().equals(ShapeShadingType.OUTLINE_AND_FILLED_IN)){
                graphics2d.fillOval(getX(), getY(), getNewWidth(), getNewHeight());
                graphics2d.setStroke(new BasicStroke(5));
                graphics2d.setColor(ShapeColor.getColor(appState.getActiveSecondaryColor()));
                graphics2d.drawOval(getX(), getY(), getNewWidth(), getNewHeight());
                }

    */