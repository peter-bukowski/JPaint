package main;

import model.ShapeColor;
import model.ShapeShadingType;
import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import java.awt.*;

public class drawTriangle implements drawStrategy {
    private int x[];
    private int y[];
    private PaintCanvasBase paintCanvas;
    private IApplicationState appState;


    public drawTriangle(PaintCanvasBase paintCanvas, IApplicationState appState, int[] x, int[] y){
        this.paintCanvas=paintCanvas;
        this.appState=appState;
        this.x=x;
        this.y=y;
        if(appState.getActiveShapeShadingType().equals(ShapeShadingType.FILLED_IN)) {
            drawFilled();
        }
        if(appState.getActiveShapeShadingType().equals(ShapeShadingType.OUTLINE)) {
            drawOutline();
        }
        if(appState.getActiveShapeShadingType().equals(ShapeShadingType.OUTLINE_AND_FILLED_IN)) {
            drawOutlineFilled();
        }

    }
    @Override
    public void drawOutline() {
        Graphics2D graphics2d = paintCanvas.getGraphics2D();
        graphics2d.setColor(ShapeColor.getColor(appState.getActivePrimaryColor()));
        graphics2d.drawPolygon(x,y,3);

    }

    @Override
    public void drawFilled() {
        Graphics2D graphics2d = paintCanvas.getGraphics2D();
        graphics2d.setColor(ShapeColor.getColor(appState.getActivePrimaryColor()));
        graphics2d.fillPolygon(x,y,3);
    }

    @Override
    public void drawOutlineFilled() {
        Graphics2D graphics2d = paintCanvas.getGraphics2D();
        graphics2d.setColor(ShapeColor.getColor(appState.getActivePrimaryColor()));
        graphics2d.fillPolygon(x,y,3);
        graphics2d.setStroke(new BasicStroke(5));
        graphics2d.setColor(ShapeColor.getColor(appState.getActiveSecondaryColor()));
        graphics2d.drawPolygon(x,y,3);

    }
}
