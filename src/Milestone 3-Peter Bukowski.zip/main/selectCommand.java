package main;

import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import java.awt.*;
import java.util.ArrayList;

public  class selectCommand implements ICommand {
    private Point startPoint;
    private Point endPoint;
    private PaintCanvasBase paintCanvas;
    private IApplicationState appState;
    private Shape s;


    public selectCommand(Point startPoint, Point endPoint, PaintCanvasBase paintCanvas, IApplicationState appState) {
        this.startPoint = startPoint;
        this.endPoint = endPoint;
        this.paintCanvas = paintCanvas;
        this.appState = appState;
    }

    @Override
    public void run() {
        Point point=new Point(Math.min(startPoint.getX(),endPoint.getX()),Math.min(startPoint.getY(),endPoint.getY()));
        int width= Math.abs(endPoint.getX()-startPoint.getX());
        int height= Math.abs(endPoint.getY()-startPoint.getY());
        Rectangle rect= new Rectangle(point.getX(),point.getY(),width,height);
        Boolean answer;
        for (Shape s : appState.getShapelist()) {
            answer=isCollision(rect,s);
            if(answer==true){
                s.selectShape();
                s.setSelected(true);
            }
            if(answer==false){
                s.setSelected(false);
                s.clearShape();
                s.drawShape();
                
            }

        }



        }
        public boolean isCollision(Rectangle invisible, Shape s){
        int inviX= (int) invisible.getX();
        int inviY= (int) invisible.getY();
        int inviWidth= (int) invisible.getWidth();
        int inviHeight = (int) invisible.getHeight();
        return (inviX+inviY) > s.getX() && (inviY+inviHeight)>s.getY() && (s.getX() + s.getNewWidth()) > inviX && (s.getY() + s.getNewHeight()) > inviY;

    }

}
