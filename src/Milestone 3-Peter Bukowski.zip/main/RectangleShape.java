package main;

import model.ShapeColor;
import model.ShapeShadingType;
import model.interfaces.IApplicationState;
import view.interfaces.PaintCanvasBase;

import java.awt.*;

 class RectangleShape extends Shape {

     int newWidth;
     int newHeight;
     Point selectPoint;
     int x;
     int y;
     drawStrategy drawRect;


     public RectangleShape(Point startPoint, Point endPoint, PaintCanvasBase paintCanvas, IApplicationState appState) {
         this.startPoint = startPoint;
         this.endPoint = endPoint;
         this.paintCanvas = paintCanvas;
         this.appState = appState;
         newWidth= Math.abs(endPoint.getX() - startPoint.getX());
         newHeight=Math.abs(endPoint.getY() - startPoint.getY());
         selectPoint=new Point(Math.min(startPoint.getX(),endPoint.getX()),Math.min(startPoint.getY(),endPoint.getY()));
         x=selectPoint.getX();
         y=selectPoint.getY();
        // drawShape();
     }

     public void drawShape() {
         drawRect = new drawRectangle(paintCanvas, appState, getX(), getY(), getNewWidth(), getNewHeight());


     }




     @Override
     public Boolean isPolygon() {
         isPoly = false;
         return isPoly;
     }

     @Override
     public void setSelected(Boolean answ) {
         isSelected=answ;

     }

     @Override
     public Boolean IsSelected() {
         return isSelected;
     }

     @Override
     public void clearShape() {

           Graphics2D graphics2d = paintCanvas.getGraphics2D();
          graphics2d.setColor(Color.WHITE);
          graphics2d.fillRect(getX()-10, getY()-10,getNewWidth()+20,getNewHeight()+20);
     }

     @Override
     public void setX(int point) {
         x = point;
     }

     @Override
     public void setY(int point) {
       y=point;
     }

     @Override
     public void setX1(int point) {

     }

     @Override
     public void setY1(int point) {

     }

     @Override
     public void setNewX() {

     }

     @Override
     public void setNewY() {

     }

     public void selectShape() {

         Graphics2D graphics2d = paintCanvas.getGraphics2D();
         Stroke stroke = new BasicStroke(3, BasicStroke.CAP_BUTT, BasicStroke.JOIN_BEVEL, 1, new float[]{9}, 0);
         graphics2d.setStroke(stroke);
         graphics2d.setColor(Color.BLACK);
         graphics2d.drawRect(getX()-5, getY()-5, getNewWidth()+10, getNewHeight()+10);
     }


     public int getNewWidth() {
         return newWidth;
     }

     public int getNewHeight() {
         return newHeight;
     }

     public int getX() {
         return x;
     }

     public int getY() {
         return y;
     }

     @Override
     public int getX1() {
         return 0;
     }

     @Override
     public int getY1() {
         return 0;
     }





 }
     /*Graphics2D graphics2d = paintCanvas.getGraphics2D();
        graphics2d.setColor(ShapeColor.getColor(appState.getActivePrimaryColor()));
                if(appState.getActiveShapeShadingType().equals(ShapeShadingType.FILLED_IN)) {
                graphics2d.fillRect(getX(), getY(), getNewWidth(), getNewHeight());

                }
                if(appState.getActiveShapeShadingType().equals(ShapeShadingType.OUTLINE)){
                graphics2d.drawRect(getX(), getY(), getNewWidth(), getNewHeight());
                }
                if(appState.getActiveShapeShadingType().equals(ShapeShadingType.OUTLINE_AND_FILLED_IN)){
                graphics2d.fillRect(getX(), getY(), getNewWidth(), getNewHeight());
                graphics2d.setStroke(new BasicStroke(5));
                graphics2d.setColor(ShapeColor.getColor(appState.getActiveSecondaryColor()));
                graphics2d.drawRect(getX(), getY(), getNewWidth(), getNewHeight());

                }

      */