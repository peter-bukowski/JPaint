package main;

import model.interfaces.IApplicationState;

import java.awt.*;

public class pasteCommand  implements ICommand {
    private IApplicationState appState;

    public pasteCommand(IApplicationState appState) {
        this.appState=appState;
    }
    @Override
    public void run() {
        Boolean result;
        for(Shape s: appState.getCopyList()){
            int x= Math.abs(s.getX()-s.getX1());
            int y= Math.abs(s.getY()-s.getY1());
           result= s.isPolygon();
            if(result==true){
                s.setX(0);
                s.setY(0);
                s.setX1(s.getX()+x);
                s.setY1(s.getY()+y);
                s.setNewX();
                s.setNewY();
                s.drawShape();
            }
            s.setX(0);
           s.setY(0);
            s.drawShape();
        }

    }
}
