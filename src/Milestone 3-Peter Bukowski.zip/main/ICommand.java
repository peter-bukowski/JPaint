package main;

public interface ICommand {
    public void run();
}
